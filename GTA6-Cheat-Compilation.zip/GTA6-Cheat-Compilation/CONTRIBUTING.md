# Contributing

1. Fork the repository.
2. Add information to the appropriate category.
3. Include platform details.
4. Include a source for claims that can be independently verified.
5. Do not add online exploits, account-stealing tools, malware, or anti-cheat bypasses.
6. Submit a pull request with a clear description of your changes.
