# Sources

Use this page to record where each confirmed cheat/code was obtained.

Prefer official Rockstar information or reliable, verifiable sources.
