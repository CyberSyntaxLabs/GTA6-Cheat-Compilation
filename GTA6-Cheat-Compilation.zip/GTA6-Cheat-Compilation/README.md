# 🎮 GTA 6 Cheat Compilation

A community-maintained compilation of GTA 6 cheat codes, commands, and gameplay tricks for offline/single-player gameplay.

> ⚠️ This repository is intended for single-player/offline gameplay. Do not use cheats, exploits, or unauthorized tools to gain an advantage in GTA Online or bypass security/anti-cheat systems.

## Categories
- 🧍 Player Cheats
- 🚗 Vehicle Cheats
- 🔫 Weapon Cheats
- 🌎 World & Environment
- 🎮 Gameplay & Miscellaneous

## Cheat format
Each entry should contain:
- **Name**
- **Effect**
- **Platform**
- **Input/Command**
- **Notes**
- **Source**

## Status
🚧 Community compilation in progress

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md).
